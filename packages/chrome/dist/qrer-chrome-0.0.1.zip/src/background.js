chrome.runtime.onInstalled.addListener(function() {
    console.log("Qrer lives!");
});